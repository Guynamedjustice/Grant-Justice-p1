//Setting up variables
var greeting;
var tColor;
var time = new Date().getHours();
//Creating statements to check the hour
if (time<12){
    greeting = "Good Morning";
    tColor = "bgColor1";
}
else if (time<18){
    greeting = "Good Afternoon";
    tColor = "bgColor2";
}
else {
    greeting = "Good Night";
    tColor = "bgColor3";
}
// Statements that write to the document
document.getElementById("myGreeting").innerHTML = greeting;
document.getElementsByClassName("bgColor1").className = tColor;
